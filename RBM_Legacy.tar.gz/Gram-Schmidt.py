#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Tue Feb 18 17:26:11 2020

@author: german
"""

def normalisation(U):
    # u is a
    normaU_ = tf.sqrt(tf.math.reduce_sum(tf.multiply(U_,U_,1),axis=1))

def gs_cofficient(v1, v2):
    return tf.tensordot(v2, v1,1) / tf.tensordot(v1, v1,1)

def proj(v1, v2):
    return tf.multiply(v1,gs_cofficient(v1, v2) )

def Gram_Schmidt_process(X):
    # First, normalise all the vectors

    tf.tensordot(v1, v1,1)
    Y = []
    for i in range(len(X)):
        temp_vec = X[:,i]
        print(temp_vec,tf.sqrt(tf.tensordot(temp_vec, temp_vec,1)),i)            
        temp_vec = temp_vec/tf.sqrt(tf.tensordot(temp_vec, temp_vec,1))            
        print(temp_vec,tf.sqrt(tf.tensordot(temp_vec, temp_vec,1)),i)            

        for inY in Y :
            proj_vec = proj(inY, X[:,i])
            print(proj_vec)
            temp_vec = tf.math.subtract(temp_vec, proj_vec,1)
            print(temp_vec)
           # temp_vec = temp_vec/tf.sqrt(tf.tensordot(temp_vec, temp_vec,1))     
            print(temp_vec,tf.sqrt(tf.tensordot(temp_vec, temp_vec,1)),i)            
        Y.append(temp_vec)     
    Y = np.stack(Y)
    return Y


import tensorflow as tf
import numpy as np
H   = 0.5*tf.constant([[ 1.0,1.0], [ 1.0,-1.0 ]],dtype=tf.float32)
theta = tf.constant(3.1415926/7.1323,dtype=tf.float32)
#U   = tf.constant([[np.cos(theta)+0.12, -np.sin(theta)],[np.sin(theta), np.cos(theta)-0.2442]],dtype=tf.float32)
U   = tf.constant([[1.3,1.4],[1.7,-1.4]],dtype=tf.float32)
print(U)
U = Gram_Schmidt_process(U)
print(U)
#print(tf.sqrt(tf.tensordot(U, U,1)))
