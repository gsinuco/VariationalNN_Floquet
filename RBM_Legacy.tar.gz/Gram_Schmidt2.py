#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Tue Feb 18 19:40:09 2020

@author: german

copied from
https://gist.github.com/iizukak/1287876
"""
import tensorflow as tf
import numpy as np

def normalisation(U_):
    # U_  (in) original matrix
    #     (out)  matrix with normalised vectors
    normaU_ = tf.sqrt(tf.math.reduce_sum(tf.multiply(U_,U_,1),axis=0))
    #print(tf.multiply(U_,U_,1))
    #print(tf.reduce_sum(tf.multiply(U_,U_,1),axis=0))
    U__ = tf.math.truediv(U_,normaU_)
    return U__

def Gram_Schmidt(U_):
    U_ = normalisation(U_)
    Y = []
    for i in range(0,tf.shape(U_).numpy()[0]):
        
        temp_vec = U_[:,i]
        
        for inY in Y:
            
            norminY    = tf.math.reduce_sum(tf.multiply(inY,inY,0)).numpy()
            projec_vec = tf.math.multiply(tf.math.reduce_sum(tf.multiply(U_[:,i],inY,0))/norminY,inY)
            temp_vec   = tf.math.subtract(temp_vec,projec_vec)
              
        temp_vec = normalisation(temp_vec)     
        Y.append(temp_vec)    

    Y = np.transpose(np.stack(Y))
    return Y



def Gram_Schmidt_V2(U_):
    U_ = normalisation(U_)
    print(U_)
    proj = tf.tensordot(U_[:,0],U_,axes=1)
    print(proj)
    U_= tf.math.subtract(U_,tf.math.multiply(proj,U_))
    print(tf.math.subtract(U_,tf.math.multiply(proj,U_)))
    #print(tf.math.multiply(proj,U_))
    U_ = U_[:,1].assign(U_[:,0])
    print(tf.executing_eagerly())

    #U_ = tf.math.subtract(U_,U_)
    return U_


def gram_schmidt_columns(X):
    Q, R = np.linalg.qr(X)
    return Q    
    
#with tf.compat.v1.Session() as sess:

#    U_ = tf.constant([[3.0, 1.0], [2.0, 2.0]],dtype=tf.float32)
    #test1 = np.array([[3.0, 1.0], [2.0, 2.0]])
    #test2 = np.array([[1.0, 1.0, 0.0], [1.0, 3.0, 1.0], [2.0, -1.0, 1.0]])
U_ = tf.Variable([[1.0, 1.0, 0.0, 5.0], [1.0, 3.0, 1.0,8.0],
                  [2.0, 1.0, 1.0,-4.0],[2.0, -1.0, 1.0, -3.0]],dtype=tf.float32)
    #U   = tf.constant([[1.3,1.4],[1.7,-1.5]],dtype=tf.float32)
print(U_)
    #print(normalisation(test2))
#    normaU_ = tf.sqrt(tf.reduce_sum(tf.multiply(U_,U_)))
    
    #print(tf.multiply(U_,U_,1))
    #print(tf.reduce_sum(tf.multiply(U_,U_,1),axis=0))
 #   U_ = tf.math.truediv(U_,normaU_)
#Y_ = Gram_Schmidt_V2(test3)
 
aa=tf.Variable(tf.zeros([3,3], tf.int32))
aa=aa[1,2].assign(1)

U__ = normalisation(U_)
print(U__)
proj = tf.tensordot(U__[:,0],U__,axes=1)
print(proj)
U__= tf.math.subtract(U_,tf.math.multiply(proj,U__))
print(U__)
#print(tf.math.subtract(U_,tf.math.multiply(proj,U_)))
U_ = U_[:,1].assign(U__[:,1])
print(U_)
#print(tf.executing_eagerly())
    #print(Y_[0,0])

 #   a = tf.constant(5.0,name="a")
 #   b = tf.constant(5.0,name="b")
 #   c = tf.add(a,b,name="sumar")
 #   v = tf.Variable([1,3])
 #   v[1] = 3.0
    #Test data
 #   result = sess.run(normaU_)
 #   print(result)
 #   resultC = sess.run(c)


#normaU_ = tf.sqrt(tf.math.reduce_sum(tf.multiply(Y,Y,1),axis=0))

#print(np.matmul(np.transpose(Y),Y))
#print(gram_schmidt_columns(test3))
#print np.array(gs(test))
#print np.array(gs(test2))
#@srbhp
