#!/usr/bin/env python3
"""
Created on Wed Feb 12 10:44:59 2020

@author: German Sinuco

Skeleton modified from 
https://www.tensorflow.org/tutorials/customization/custom_training
https://www.tensorflow.org/tutorials/customization/custom_training_walkthrough
                       
Training of an RBM parametrization of the unitary matrix that diagonalises the  2x2 real,
and symmetric HAMILTONIAN:

H = delta S_z + Omega/2 S_x

The UNITARY TRANSFORMATION that diagonalises this matrix is

U = [[cos(theta) sin(theta)][-sin(theta) cos(theta)]]

with 

cos(2*theta) =  -delta/2/(sqrt(delta^2 + (Omega/2)**2)/2)
sin(2*theta) =   Omega/2/(sqrt(delta^2 + (Omega/2)**2)/2)

The diagonalised matrix is reached after applying:
    
U^dagger H U, 

which give us:
    
H = [[-sqrt(delta^2+(Omega/2)^2)/2 0][0 sqrt(delta^2 +(Omega/2)^2)]]

Here we 

Parametrize the elementes of the matrix using a RESTRICTED BOLTZMAN MACHINE

U_ji = sqrt(P(x)_(b,c,W)/Z)

with:
    
x = j,i
 
and
    
P(x)_(b,c,W) = exp(b_ji . x) Prod_l=1^M 2 x cosh(c_l + W_{x,l} . x)

Z = sum_x P(x)_(b,c,W)

"""

from __future__ import absolute_import, division, print_function, unicode_literals
import tensorflow as tf
import numpy as np
import math as m
from scipy.stats import unitary_group


class Model(object):
  def __init__(self):

    # Hamiltonian parameters
    self.delta = 1.00
    self.Omega  = 0.10

    # Initialize the spin value and number of floquet channels
    self.hidden = 10  # hidden neurons
    self.S   = 4      # spin 3.2. Hilbert space dimension
    #self.S   = 2     # spin 1/2. Hilbert space dimension
    self.N   = 0      # Number of positive Floquet manifolds
    self.dim = self.S*(2*self.N+1) # Dimension of the extended floquet space
    
    uf_      = tf.random.stateless_uniform([self.dim,self.dim],seed=[2,1],dtype=tf.float32,minval=0.0,maxval=1.0)      
    s,u,v    = tf.linalg.svd(uf_, full_matrices=True)
    uf_      = u
    
    # Declaring training variables
    self.W   = tf.Variable(tf.random.stateless_uniform([self.hidden,self.dim*self.dim,2],
                                                       seed=[1,1],dtype=tf.float32,minval=0.0,maxval=1.0),trainable=True) 
    self.b   = tf.Variable(tf.random.stateless_uniform([self.dim*self.dim,2], 
                                                       seed=[1,1],dtype=tf.float32,minval=0.0,maxval=1.0),trainable=True)
    self.c   = tf.Variable(tf.random.stateless_uniform([self.hidden],                    
                                                       seed=[1,1],dtype=tf.float32,minval=0.0,maxval=1.0),trainable=True)
    self.UF  = tf.Variable(uf_,dtype = tf.float32,trainable = True)  # ext. micromotion operator
    #print(uf_)
    self.x = tf.Variable([[0.0,0.0]],dtype=tf.float32)
    for i in range(1,self.dim+1):        
        for j in range(1,self.dim+1):
            y = [[i-2.5,j-2.5]]
            self.x = tf.concat([self.x, y], 0) 
    #print(self.x)
    #print(self.b)
    #print(self.c)
    #print(self.W)
    #print(tf.multiply(x[1:17],self.W[1]))
    #P(x)(b,c,W) = exp(bji . x) Prod_l=1^M 2 x cosh(c_l + W_{x,l} . x)
    WX = [tf.reduce_sum(tf.multiply(self.x[1:17],self.W[0]),1)+self.c[0]]
    for j in range(1,self.hidden):
        y = tf.reduce_sum(tf.multiply(self.x[1:17],self.W[j]),1)+self.c[j]
        WX = tf.concat([WX, [y]], 0) 
    
    
    UF = tf.multiply(tf.reduce_prod(tf.math.cosh(WX),0),tf.transpose(tf.reduce_sum(tf.multiply(self.x[1:17],self.b),1)))
    UF = tf.reshape(UF,[self.dim,self.dim])
    UF =  normalisation(UF)
    #print(UF)
    #print(Gram_Schmidt(UF))
    #print(tf.tensordot(self.W,x[1],[[2],[1]]))
    #print(self.UF)
    #print(tf.multiply(x,self.b))
    #print(tf.transpose(tf.reduce_sum(tf.multiply(x,self.b),1)))
    
    if self.S == 2:
        # spin 1/2 
        Identity   =     tf.constant([[1.0,0.0],[ 0.0, 1.0]],dtype = tf.float32)
        Sx         = 0.5*tf.constant([[0.0,1.0],[ 1.0, 0.0]],dtype = tf.float32)
        Sz         = 0.5*tf.constant([[1.0,0.0],[ 0.0,-1.0]],dtype = tf.float32)
    else:
        if self.S == 4:
        # spin 3/2
            Identity   =     tf.constant([[1.0,0.0,0.0,0.0],
                                  [0.0,1.0,0.0,0.0],
                                  [0.0,0.0,1.0,0.0],
                                  [0.0,0.0,0.0,1.0]],dtype = tf.float32)
            Sx         = 0.5*tf.constant([[0.0,         np.sqrt(3.0),0.0,          0.0],
                                  [np.sqrt(3.0),0.0,         np.sqrt(4.0), 0.0],
                                  [0.0,         np.sqrt(4.0),0.0,          np.sqrt(4.0)],
                                  [0.0,         0.0,         np.sqrt(3.0), 0.0]],dtype = tf.float32)
            Sz         = 0.5*tf.constant([[3.0,0.0, 0.0, 0.0],
                                  [0.0,1.0, 0.0, 0.0],
                                  [0.0,0.0,-1.0, 0.0],
                                  [0.0,0.0, 0.0,-3.0]],dtype = tf.float32)

    
    
    self.H_TLS = tf.Variable(self.delta*Sz+0.5*self.Omega*Sx,shape=(self.dim,self.dim),dtype = tf.float32,trainable = False)  # ext. Hamiltonian
        
    self.trainable_variables = [self.W,self.b,self.c]#[self.UF,self.W,self.b,self.c]
    #self.trainable_variables = self.UF
    
  def getH(self):
    return self.H_TLS
    
  def __call__(self):     
    #WX = [tf.reduce_sum(tf.multiply(self.x[1:17],self.W[0]),1)+self.c[0]]
    #for j in range(1,self.hidden):
    #    y = tf.reduce_sum(tf.multiply(self.x[1:17],self.W[j]),1)+self.c[j]
    #    WX = tf.concat([WX, [y]], 0) 
    
    
    #UF = tf.sqrt(tf.multiply(tf.reduce_prod(tf.math.cosh(WX),0),tf.transpose(tf.reduce_sum(tf.multiply(self.x[1:17],self.b),1))))
    #UF = tf.reshape(self.UF,[self.dim,self.dim])
    #self.UF = Gram_Schmidt(self.UF)
    
    return self.H_TLS




###########################################################
    
def normalisation(U_):
    # U_  (in) original matrix
    #     (out)  matrix with normalised vectors
    normaU_ = tf.sqrt(tf.math.reduce_sum(tf.multiply(U_,U_,1),axis=0))
    U_ = tf.math.truediv(U_,normaU_)
    return U_

def Gram_Schmidt(U_):
    U_ = normalisation(U_)
    #print(U_)
    Y_ = []
    #Y  = tf.Variable(np.empty([tf.shape(U_).numpy()[0],tf.shape(U_).numpy()[0]],dtype=np.float32))
    #Y.assign(U_)
    for i in range(0,tf.shape(U_).numpy()[0]):
        
        temp_vec = U_[:,i]
        #print(temp_vec)
        for inY in Y_:
            
            norminY    = tf.math.reduce_sum(tf.multiply(inY,inY,0)).numpy()
            projec_vec = tf.math.multiply(tf.math.reduce_sum(tf.multiply(U_[:,i],inY,0))/norminY,inY)
            print(i,projec_vec,norminY)
            temp_vec   = tf.math.subtract(temp_vec,projec_vec)
            
        temp_vec = normalisation(temp_vec)     
        Y_.append(temp_vec)    

    Y_ = np.transpose(np.stack(Y_))
    U_ = Y_#U_.assign(Y_)

    # maybe it's worth to lose the conribution to the gradient from the GramSchmidt calculation.
    # but getting an orthonormal basis after applying the gradients it's needed to obtain 
    # UF
    # maybe replace UF = UF + Y - UF
    # o hacerlo sin eager mode
    return Y_

def train(model,learning_rate):
  with tf.GradientTape() as t:
    current_loss = loss(model)
  dU = t.gradient(current_loss, model.trainable_variables)
  model.UF.assign_sub(learning_rate*dU)
    #where should I obtain the unitary matrix? after this step?
    # should we apply a constrain as the one in the finantial applications?
    
    
###############################################################################
    
 # 3e. Loss function := Use U^dagger H U, sum over the columns, take the difference with the diagonal, 
#     the loss function is the summ of the square of these differences. 

def loss(model):
  # define the loss function explicitly including the training variables: self.W, self.b
  # model.UF is a function of self.W,self.b,self.c

  WX = [tf.reduce_sum(tf.multiply(model.x[1:17],model.W[0]),1)+model.c[0]]
  for j in range(1,model.hidden):
        y = tf.reduce_sum(tf.multiply(model.x[1:17],model.W[j]),1)+model.c[j]
        WX = tf.concat([WX, [y]], 0) 
    
    
  #model.UF = tf.sqrt(tf.multiply(tf.reduce_prod(tf.math.cosh(WX),0),
  #                         tf.transpose(tf.reduce_sum(tf.multiply(model.x[1:17],model.b),1))))
  #model.UF = tf.reshape(model.UF,[model.dim,model.dim])
  #model.UF = Gram_Schmidt(model.UF)
  #model.UF = normalisation(model.UF)
  UF = tf.multiply(tf.reduce_prod(tf.math.cosh(WX),0),
                           tf.transpose(tf.reduce_sum(tf.multiply(model.x[1:17],model.b),1)))
  UF = tf.reshape(UF,[model.dim,model.dim])
  #UF = Gram_Schmidt(UF)    
  UF = normalisation(UF)

  U = UF
  #U = normalisation(U)
  print(UF)
  print(Gram_Schmidt(UF))  
  
  i = 1
  temp_vec = U[:,1]
  inY = U[:,0]
  norminY    = tf.math.reduce_sum(tf.multiply(inY,inY,0)).numpy()
  projec_vec = tf.math.multiply(tf.math.reduce_sum(tf.multiply(U[:,1],inY,0))/norminY,inY)
  print(i,projec_vec,norminY)    
    
  proj = tf.tensordot(UF[:,0],UF,axes=1)
  print(proj)
  U = tf.math.subtract(UF,tf.math.multiply(proj,UF))
  print(U) 
  #U = normalisation(U)
  #proj = tf.tensordot(U[:,1],UF,axes=1)
  #print(proj)
  #U = tf.math.subtract(UF,tf.math.multiply(proj,UF))
  #print(U) 
  #proj = tf.tensordot(U[:,2],UF,axes=1)
  #print(proj)
  #U = tf.math.subtract(UF,tf.math.multiply(proj,UF))
  #print(U) 
  #proj = tf.tensordot(U[:,3],UF,axes=1)
  #print(proj)
  #U = tf.math.subtract(UF,tf.math.multiply(proj,UF))
  #print(U) 

  #U = U_[:,1].assign(U__[:,1])
 
  #print(UF) 
  #print(tf.transpose(UF)@UF)
  #U_ = tf.abs(tf.transpose(model.UF)@model.H_TLS@model.UF)
  U_ = tf.abs(tf.transpose(UF)@model.H_TLS@UF)
  U_diag = tf.linalg.tensor_diag_part(U_)  
  dotProd = tf.math.reduce_sum(U_,axis=1,)
  residual = tf.math.reduce_sum(tf.pow((U_diag-dotProd),2),0)
  return residual

# This is the gradient of the loss function. required for keras optimisers
def grad(model):
  with tf.GradientTape() as tape:
    loss_value = loss(model)
  return loss_value, tape.gradient(loss_value, model.trainable_variables)


optimizer = tf.keras.optimizers.SGD(learning_rate=0.01)

model = Model()
# Collect the history of W-values and b-values to plot later
#Us = [], []
learning_rate =0.01
epochs = range(1)
U = tf.constant([[1.0,2.0,3.0,4.0],[5.0,6.0,7.0,8.0],[9.0,10.0,11.0,12.0],[13.0,14.0,15.0,16.0]],dtype=tf.float32)
#U = normalisation(U)
print(U)
print("")
i = 1
temp_vec = U[:,1]
inY = U[:,0]
norminY    = tf.math.reduce_sum(tf.multiply(inY,inY,0)).numpy()
print(tf.multiply(U[:,1],inY,0))
projec_vec = tf.math.multiply(tf.math.reduce_sum(tf.multiply(U[:,1],inY,0))/norminY,inY)
#print(i,projec_vec,norminY)    
#print("")    
proj = tf.tensordot(U[:,0],U,axes=1)
#print(i,proj)
U = tf.math.subtract(U,tf.math.multiply(proj,U))
#print("")
#print(U) 

#for i in epochs:
#    loss_value, grads = grad(model)
    #print(grads)
    #model.UF.assign_sub(learning_rate*grads)
    #model.UF.assign(Gram_Schmidt(model.UF))
    #print(model.UF)

    #print("Step: {}, Initial Loss: {}".format(optimizer.iterations.numpy(),
    #                                      loss_value.numpy()))

    #print(model.trainable_variables)
   # optimizer.apply_gradients(zip(grads, model.trainable_variables))
    
    #model()
  #  print("Step: {},         Loss: {}".format(optimizer.iterations.numpy(),
  #                                        loss(model).numpy()))
    #model.UF = Gram_Schmidt(model.UF)
    #model.UF.assign(Gram_Schmidt(model.UF))
    #model()
    #Gram_Schmidt(model.UF)


#print(model.UF)
#print(current_loss.numpy())
#print(model.UF.numpy())
#print(tf.transpose(model.UF)@(model.H_TLS@model.UF))
 
 
  